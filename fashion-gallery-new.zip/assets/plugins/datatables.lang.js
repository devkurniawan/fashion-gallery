const newLocal = {
  "language": {
    "search": "Cari:",
    "lengthMenu": "Menampilkan _MENU_ data",
    "info": "Menampilkan _START_ sampai _END_ data dari _TOTAL_ data",
    "infoEmpty": "Tidak ada data yang ditampilkan",
    "infoFiltered": "(dari total _MAX_ data)",
    "zeroRecords": "Tidak ada hasil pencarian ditemukan",
    "paginate": {
      "first": "&laquo;",
      "last": "&raquo;",
      "next": "&rsaquo;",
      "previous": "&lsaquo;"
    },
  }
};
var options = newLocal;